
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.linear_model import LinearRegression

household_data = pd.DataFrame({
    'Region': ['North West', 'South West', 'EA Wales', 'North East', 'Anglian',
               'Midlands', 'Southern', 'Thames', 'South East'],
    'Households_Millions': [3.2, 2.5, 1.4, 1.2, 2.6, 4.5, 3.6, 3.8, 3.6]  # In millions
})
household_data['Households_Thousands'] = household_data['Households_Millions'] * 1000  # Convert to thousands


pollution_incidents = pd.DataFrame({
    'Region': ['North West', 'South West', 'EA Wales', 'North East', 'Anglian',
               'Midlands', 'Southern', 'Thames', 'South East'],
    'Pollution_Incidents': [126, 108, 13, 121, 76, 100, 300, 331, 108]
})


merged_data = pd.merge(household_data, pollution_incidents, on='Region')

# Prepare data for regression
X = merged_data[['Households_Thousands']].values  
y = merged_data['Pollution_Incidents'].values  


model = LinearRegression()
model.fit(X, y)


merged_data['Predicted_Incidents'] = model.predict(X)


merged_data['Above_Regression'] = merged_data['Pollution_Incidents'] > merged_data['Predicted_Incidents']


sns.set(style='whitegrid')

# Custom color palette
above_color = '#D80E0E'  
below_color = '#FA540A'  


colors = [above_color if above else below_color for above in merged_data['Above_Regression']]


plt.figure(figsize=(12, 8))
scatter = sns.scatterplot(data=merged_data, x='Households_Thousands', y='Pollution_Incidents', hue=merged_data['Above_Regression'], palette=[below_color, above_color], s=100, edgecolor='w', alpha=0.8)


sns.regplot(data=merged_data, x='Households_Thousands', y='Pollution_Incidents', scatter=False, color='red', line_kws={"linestyle":"--"})


for i in range(len(merged_data)):
    scatter.text(merged_data['Households_Thousands'][i], merged_data['Pollution_Incidents'][i], merged_data['Region'][i], 
                 horizontalalignment='left', size='medium', color='black', weight='semibold')


plt.title('Correlation Between Number of Households and Pollution Incidents (2022)', fontsize=16, weight='bold')
plt.xlabel('Number of Households (in thousands)', fontsize=14)
plt.ylabel('Number of Pollution Incidents', fontsize=14)


handles, _ = scatter.get_legend_handles_labels()
plt.legend(handles, ['Below Regression Line', 'Above Regression Line'], title='Region Type', bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=12)


plt.grid(True)
plt.tight_layout()


plt.show()


correlation_coefficient = merged_data['Households_Thousands'].corr(merged_data['Pollution_Incidents'])
print(f'Correlation coefficient: {correlation_coefficient:.2f}')
