
import pandas as pd
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go

# 
data = pd.read_csv('measurment_data.csv')

# 
non_numeric_columns = data.select_dtypes(include=['object']).columns
data[non_numeric_columns] = data[non_numeric_columns].fillna("NA")

# 
data['QUANTITY RELEASED (kg)'] = pd.to_numeric(data['QUANTITY RELEASED (kg)'], errors='coerce')

# 
water_operators_data = data[data['OPERATOR NAME'].str.contains('water', case=False, na=False)]

# 
clean_water_operators_data = water_operators_data.dropna(subset=['QUANTITY RELEASED (kg)'])

# 
clean_water_operators_data['OPERATOR NAME'] = clean_water_operators_data['OPERATOR NAME'].str.title()

# 
operator_release = clean_water_operators_data.groupby('OPERATOR NAME')['QUANTITY RELEASED (kg)'].sum().reset_index()

# 
top_10_water_operators = operator_release.sort_values(by='QUANTITY RELEASED (kg)', ascending=False).head(10)

# 
fig = make_subplots(
    rows=2, cols=2, 
    specs=[[{"type": "bar"}, {"type": "pie"}], [{"type": "bar"}, {"type": "box"}]], 
    subplot_titles=[
        "Water Companies by Quantity Released", 
        "Proportion of Total Emissions",
        "Quantity Released Distribution"
    ]
)

# --- Graph 1: Horizontal Bar Chart (Top 10 by Quantity Released) ---

bar_chart = px.bar(
    top_10_water_operators,
    x='QUANTITY RELEASED (kg)',
    y='OPERATOR NAME',
    orientation='h',
    text='QUANTITY RELEASED (kg)',
    color_discrete_sequence=['#005f73']  # Set all bars to a green color
)

for trace in bar_chart['data']:
    fig.add_trace(trace, row=1, col=1)

# --- Graph 2: Pie Chart (Proportion of Total Emissions) ---

custom_pie_colors = ['#005F73', '#0A9396', '#94D2BD', '#E9D8A6', '#EE9B00', 
                     '#CA6702', '#BB3E03', '#AE2012', '#9B2226', '#B1D0E0']


pie_chart = px.pie(
    top_10_water_operators, 
    values='QUANTITY RELEASED (kg)', 
    names='OPERATOR NAME',
    color='OPERATOR NAME',
    color_discrete_sequence=custom_pie_colors  # Custom colors for pie chart
)

for trace in pie_chart['data']:
    fig.add_trace(trace, row=1, col=2)

# --- Graph 3: Box Plot (Distribution of Emissions) ---
box_plot = px.box(
    clean_water_operators_data,
    y='QUANTITY RELEASED (kg)',
    points="all",  # Show all points to identify outliers
    color_discrete_sequence=['#94d2bd']  # Muted green color for elegance
)

for trace in box_plot['data']:
    fig.add_trace(trace, row=2, col=2)

# 
fig.update_layout(
    title_text='Pollution Emissions by Water Companies',
    title_font=dict(size=22, family="Arial", weight="bold"),  # Title bold and larger
    height=800,  # Set height for better visibility
    showlegend=False,  # Disable legends for bar charts
    coloraxis_colorbar=dict(title="Quantity Released (kg)", title_font=dict(size=14)),
    plot_bgcolor='white',  # White background for clean look
    margin=dict(l=80, r=50, t=100, b=60),  # Adjust margins for better spacing
    bargap=0.15  # Control the gap between bars for better presentation
)

#
fig.update_annotations(font_size=16, font=dict(family="Arial", color="black", weight="bold"))  # Bold subplot titles
fig.update_xaxes(showgrid=True, gridcolor='#eeeeee', title_text="Quantity Released (kg)", title_font=dict(size=14))  # X-axis label
fig.update_yaxes(showgrid=True, gridcolor='#eeeeee', title_text="Operator Name", title_font=dict(size=14))  # Y-axis label


fig.show()
