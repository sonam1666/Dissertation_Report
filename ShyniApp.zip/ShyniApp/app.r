# Load necessary libraries
library(sf)
library(lubridate)
library(ggplot2)
library(dplyr)
library(leaflet)
library(plotly)
library(shiny)

# Load your data
data <- read.csv("EP_Incidents_Nirs2.csv", stringsAsFactors = FALSE)

# Clean the data
data_cleaned <- data %>%
  select(-REGION_PF, -AREA_PF) %>%
  filter(REGION_WM != "") %>%
  mutate(NOT_DATE = dmy_hms(NOT_DATE)) %>%
  st_as_sf(coords = c("X_CONF", "Y_CONF"), crs = 27700) %>%
  st_transform(crs = 4326) %>%
  mutate(LATITUDE = st_coordinates(.)[, 2],
         LONGITUDE = st_coordinates(.)[, 1]) %>%
  select(NOT_ID, NOT_DATE, REGION_WM, AREA_WM, COUNTY, UNITARY, DISTRICT, NGR_CONF, LATITUDE, LONGITUDE, EP_INC, EIL_WATER) %>%
  mutate(YEAR = year(NOT_DATE))

# Define UI
ui <- fluidPage(
  titlePanel("Water Pollution Incidents Analysis"),
  
  # Add custom CSS for improved layout and styling
  tags$head(
    tags$style(HTML("
    .nav-tabs {
      border-bottom: 0px solid #ddd;
      margin-bottom: 10px;
     }
    .nav-tabs>li>a {
      border-radius: 0px;
      border:none;
    }
    .nav>li>a {
        padding: 6px 21px;
    }
    .nav-tabs>li.active>a,
    .nav-tabs>li.active>a:focus,
    .nav-tabs>li.active>a:hover {
          color: #ffffffde;
          cursor: default;
          background-color: #000;
          border-bottom-color: transparent;
          border:none;
          border-radius: 0px;
      }
    a, a:focus, a:hover {
      color: #1f2a33;
      }
      h2 {
          padding-bottom: 20px;
          padding-top: 19px;
          margin-bottom: 40px;
          margin-top: 0px;
          font-size: 18px;
          letter-spacing: 1px;
          text-align: center;
          box-shadow: 0 2px 14px rgb(2 2 4 / 9%);
          background-color: #000000;
          color: #fff;
      }
      .sidebar {
        padding: 10px 15px;
        border-radius: 6px;
        background-color: #ffffff;
        box-shadow: 0 2px 14px rgb(2 2 4 / 9%);
        border: none;
      }
      .leaflet-container {
        height: 550px !important;
      }
    "))
  ),
  
  # Add custom JavaScript to control the visibility of the region filter
  tags$script(HTML("
    $(document).ready(function() {
      // Hide region filter when other tabs are selected
      $('.sidebar').parent().show();
      
      $('a[data-toggle=\"tab\"]').on('shown.bs.tab', function (e) {
        var activeTab = $(e.target).text(); // Get the active tab text
        
        if(activeTab !== 'Heatmap') {
          $('.sidebar').parent().hide(); // Show the region filter when Heatmap is active
        } else {
          $('.sidebar').parent().show(); // Hide the region filter when other tabs are active
        }
      });
    });
  ")),
  
  sidebarLayout(
    sidebarPanel(
      class = "sidebar",
      selectInput("region", "Select Region:",
                  choices = c("All", unique(data_cleaned$REGION_WM)),  
                  selected = "All", width = "100%"),
      selectInput("year", "Select Year:",
                  choices = c("All", unique(data_cleaned$YEAR)),
                  selected = "All", width = "100%"),
      selectInput("category", "Select Pollution Category:",
                  choices = c("All", unique(data_cleaned$EIL_WATER)),
                  selected = "All", width = "100%"),
      uiOutput("pollution_count"),  # Placeholder for pollution category count
      width = 3
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Heatmap", leafletOutput("map")),
        tabPanel("Incidents Per Year", plotOutput("incidents_plot")),
        tabPanel("Correlation Plot", plotlyOutput("correlation_plot"))
      ), width = 9
    )
  )
)

# Define server logic
server <- function(input, output, session) {
  
  # Reactive expression to filter data based on selected region, year, and category
  filtered_data <- reactive({
    data_filtered <- data_cleaned
    
    if (input$region != "All") {
      data_filtered <- data_filtered %>% filter(REGION_WM == input$region)
    }
    if (input$year != "All") {
      data_filtered <- data_filtered %>% filter(YEAR == as.numeric(input$year))
    }
    if (input$category != "All") {
      data_filtered <- data_filtered %>% filter(EIL_WATER == input$category)
    }
    
    data_filtered
  })
  
  severity_colors <- colorFactor(
    palette = c("#AC0000", "#D3612C", "#E7A10B", "#9CBF00"),
    domain = unique(data_cleaned$EIL_WATER)
  )
  
  # Update the heatmap based on the filtered data
  output$map <- renderLeaflet({
    leaflet(filtered_data()) %>%
      addProviderTiles(providers$CartoDB.Positron) %>%
      addCircleMarkers(
        lng = ~LONGITUDE, lat = ~LATITUDE,
        popup = ~paste("ID:", NOT_ID, "<br>",
                       "Date:", format(NOT_DATE, "%Y-%m-%d %H:%M:%S"), "<br>",
                       "Region:", REGION_WM, "<br>",
                       "District:", DISTRICT, "<br>",
                       "Water Impact:", EIL_WATER),
        radius = 4,
        color = ~severity_colors(EIL_WATER),
        fillOpacity = 0.6,
        stroke = FALSE
      ) %>%
      addLegend("bottomright", pal = severity_colors, values = ~EIL_WATER,
                title = "Severity of Pollution",
                opacity = 1)
  })
  
  # Create a summary of incidents by pollution category (EIL_WATER)
  output$pollution_count <- renderUI({
    category_count <- filtered_data() %>%
      group_by(EIL_WATER) %>%
      summarize(count = n()) %>%
      ungroup()
    
    # Generate HTML content to display counts
    category_display <- paste0(
      "<div class='pollution-card'><strong>Pollution Category Counts:</strong><ul>",
      paste0("<li>Category ", category_count$EIL_WATER, ": ", category_count$count, "</li>", collapse = ""),
      "</ul></div>"
    )
    
    # Output the HTML as UI
    HTML(category_display)
  })
  
  # Incidents Per Year plot - Use the entire dataset, not filtered by region
  output$incidents_plot <- renderPlot({
    incidents_filtered <- data_cleaned %>%
      group_by(YEAR) %>%
      summarize(incident_count = n(), .groups = 'drop')
    
    ggplot(incidents_filtered, aes(x = YEAR, y = incident_count)) +
      geom_area(fill = "#1f78b4", alpha = 0.5) +
      geom_point(size = 1, color = "#046495") +
      theme_minimal() +
      labs(title = "Number of Water Pollution Incidents Per Year", x = "Year", y = "Incident Count") +
      scale_x_continuous(limits = c(2001, 2023), breaks = seq(2001, 2023, by = 1))  
  })
  
  
  # Correlation Plot - Convert to Bar Chart using the entire dataset, filtered from 2001 to 2023
  output$correlation_plot <- renderPlotly({
    pollution_incidents_filtered <- data_cleaned %>%
      filter(EP_INC == "Yes", YEAR >= 2015, YEAR <= 2023) %>%
      group_by(YEAR, EIL_WATER) %>%
      summarize(count = n(), .groups = 'drop') %>%
      ungroup()
    
    # Create the bar chart using ggplot2
    p <- ggplot(pollution_incidents_filtered, aes(x = factor(YEAR), y = count, fill = factor(EIL_WATER))) +
      geom_bar(stat = "identity", position = "dodge", width = 0.7) +
      scale_fill_manual(values = c("#004b86", "#b2c22a", "#5eb8ce", "#485b24"), 
                        name = "Water Impact Level") +
      theme_minimal() +
      labs(
        title = "Bar Chart of Water Pollution Incidents (2015-2023)",
        x = "Year",
        y = "Incident Count"
      ) +
      theme(
        plot.title = element_text(size = 16, face = "bold"),
        axis.text.x = element_text(angle = 45, hjust = 1)
      )
    
    # Convert the ggplot to a plotly interactive chart
    ggplotly(p)
  })
  
}

# Run the application
shinyApp(ui, server)
